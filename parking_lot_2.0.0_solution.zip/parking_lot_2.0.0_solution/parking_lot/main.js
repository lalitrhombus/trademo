const commandProcessor = require('./common/command_processor');
const fs = require('fs') 

var argv = process.argv.slice(2);
fs.readFile(argv[0], 'utf-8', (err, data) => { 
  if (err) throw err; 

  // Converting Raw Buffer to text 
  // data using tostring function. 
  // console.log(data);
  const commands = data.split('\n')
  // TODO: make this a promise so one command execute at a time
  commands.forEach((command)=>{
    commandProcessor(command);
  });
})

