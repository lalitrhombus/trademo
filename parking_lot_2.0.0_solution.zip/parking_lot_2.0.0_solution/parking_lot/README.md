# Parking Lot

`parking_lot/` contains the code for vehicle parking system, it has a main.js as entry point, which takes the file_path as argument. To run the application run `node main.js ${file_path}`.


## Setup

First, install [Node](https://nodejs.org/en/download/). Then run the following commands from the root directory.

```
npm install
node ./parking_lot/main.js ${file_path}
```

## Usage
You can run the full test suite from `npm test`